
public class Hipotecario extends Prestamo {

	public Hipotecario(int sueldo) {
		super(sueldo);
	}

	@Override
	public void damePrestamo(int sueldo) {
		this.cuota = sueldo*0.40;
		this.interes = cuota*0.3;		
	}

}
