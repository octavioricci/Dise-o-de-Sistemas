
public abstract class Prestamo {
	
	protected double interes;
	protected double cuota;
	protected int sueldo;
	
	public Prestamo(int sueldo) {
		this.sueldo = sueldo;
	}
	
	public abstract void damePrestamo(int sueldo);

}