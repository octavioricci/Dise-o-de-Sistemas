
public class main {

	
	public static void main(String[] args) {

		Prendario p = new Prendario(100);
		
		p.damePrestamo(p.sueldo);
		System.out.println(p.interes);
		System.out.println(p.cuota);
	}

}
